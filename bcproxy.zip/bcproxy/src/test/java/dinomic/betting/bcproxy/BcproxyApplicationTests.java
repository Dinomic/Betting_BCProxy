package dinomic.betting.bcproxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BcproxyApplicationTests {

	@Test
	void contextLoads() {
	}

}
