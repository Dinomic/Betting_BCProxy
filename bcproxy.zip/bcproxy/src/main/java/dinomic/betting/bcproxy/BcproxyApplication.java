package dinomic.betting.bcproxy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BcproxyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BcproxyApplication.class, args);
	}

}
